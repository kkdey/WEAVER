#!/usr/bin/env Rscript

library(devtools)
library(testthat)
test()
