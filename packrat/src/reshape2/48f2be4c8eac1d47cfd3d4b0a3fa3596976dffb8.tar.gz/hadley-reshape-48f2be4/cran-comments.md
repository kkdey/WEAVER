## Test environments
* local OS X install, R 3.3.1
* ubuntu 12.04 (on travis-ci), R 3.3.1
* win-builder (devel and release)

## R CMD check results

0 errors | 0 warnings | 1 note

* License components with restrictions and base license permitting such:
  MIT + file LICENSE

## Reverse dependencies

This release is just a couple of minor R CMD check fixes, so I did not check the reverse dependencies.
